
English Voices Addon (or E.V.A. for short) for Call of Chernobyl 1.5
===================================================

NOTE: Not EVERY line of dialogue is in English. The game will still be mostly in Russian.

Basic idea of the mod is to add back a lot of the English voice files from all 3 STALKER games. This release has been re-structured for version 1.5, and now offers some more options. You may now choose what NPCs use their English lines (like Sidorovich or Sakharov).

Now, for the Faction Voices...
These folders are seperated per faction, and by which game: Clear Sky or Call of Pripyat. You can install all of it, but I mainly did this in case you don't want to hear somebody talk with 2 different voices at once (not like that matters, considering it already happens enough in these games). Use it as you see fit.

"Good hunting, Stalker."